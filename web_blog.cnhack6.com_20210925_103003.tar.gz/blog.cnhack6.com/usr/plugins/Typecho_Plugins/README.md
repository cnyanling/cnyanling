# Typecho_Plugins

莫名博客：Qzone.Work

站长邮箱：admin@qzone.work

莫名博客创作插件，适用于Typecho博客系统，欢迎使用！

-------------------------------

OssImg（阿里云OSS 图床外链，基于插件(OssForTypecho)制作）

AdminLogin（后台扫码登录，支持接口：【微信，QQ】）
