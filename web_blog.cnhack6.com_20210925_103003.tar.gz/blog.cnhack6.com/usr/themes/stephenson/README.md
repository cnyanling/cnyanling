# stephenson

这个月，老蒋([www.itbulu.com][1])准备抽时间熟悉Typecho CMS程序主题模板的应用，因为有些简单的网站用这个程序比用WordPress简单一些。鉴于练手，在网上找到一款忘记名称的前端，然后简单的修改之后再套装成今天要发布的Typecho主题。这里取名为Stephenson主题。

![请输入图片描述][2]

我们可以看到这款主题是单栏，适合我们日常的个人博客实用。

![请输入图片描述][3]

在前端我还套用到Layui前端框架，自带面包屑导航，基本上是直接安装就可以使用。主题后台激活之后需要简单的设置LOGO图标（建议150*150px大小），以及可以设置自己的社交媒体，比如GITHUB、微博、邮箱，根据表单填写即可。

> 主题发布官网网站：[https://www.itbulu.com/typecho-stephenson.html][5]


  [1]: https://www.itbulu.com/
  [2]: https://raw.githubusercontent.com/itbulu/stephenson/master/Stephenson-1.jpg
  [3]: https://raw.githubusercontent.com/itbulu/stephenson/master/Stephenson-2.jpg
  [5]: https://www.itbulu.com/typecho-stephenson.html
