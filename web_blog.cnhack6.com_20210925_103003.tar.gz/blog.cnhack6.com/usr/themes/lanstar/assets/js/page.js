lanstar.addEmoji()
lanstar.addHighLight();
lanstar.addCatalog()
lanstar.addComment();
lanstar.addPageLike();
lanstar.addArchiveToggle()
lanstar.addPostProtect();
lanstar.addCommentSecret();
