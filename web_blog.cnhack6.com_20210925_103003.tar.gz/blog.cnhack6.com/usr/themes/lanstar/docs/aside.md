这里要说就是媒体信息的添加

**<u>名称+图标+地址，一行一个</u>**

例子：github+icon-xxx+https://github.com/dyedd