## 音乐播放器

```
server="netease" type="playlist" id="60198"
id	require	song id / playlist id / album id / search keyword

server	require	music platform: netease, tencent, kugou, xiami, baidu

type	require	song, playlist, album, search, artist
```

更多设置可以查阅 [点击](https://github.com/metowolf/MetingJS)